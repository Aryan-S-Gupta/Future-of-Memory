#!/usr/bin/env python
print('Django entry point placeholder')